let nombre = prompt("Ingresa tu nombre");

let continuar = true;
while (continuar) {
  let nota1 = parseInt(prompt("Ingresa tu nota de primer examen"));
  let nota2 = parseInt(prompt("Ingresa tu nota de segundo examen"));

  let promedio = (nota1 + nota2) / 2;

  let estado = "";
  if (promedio >= 6) {
    estado = "Aprobado!";
  } else {
    estado = "Desaprobado";
  }

  alert(`${nombre}, tu promedio es ${promedio.toFixed(1)}. Estás ${estado}.`);
  let respuesta = prompt("¿Deseas ingresar notas para otro alumno?");
  if (respuesta.toLowerCase() !== 'si') {
    continuar = false;

}}
